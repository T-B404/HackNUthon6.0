import { useEffect } from "react";

const EXTENSION_URL = "https://chrome.google.com/webstore/detail/gejcolgceaggbiegbmgfdkgegddfikag";

const installExtension = () => {
    if (window.chrome?.webstore?.install) {
        window.chrome.webstore.install(
            EXTENSION_URL,
            () => alert("Extension installed successfully!"),
            (error) => alert("Installation failed: " + error)
        );
    } else {
        alert("Please visit the Chrome Web Store to install the extension.");
        window.open(EXTENSION_URL, "_blank");
    }
};

const App = () => {
    useEffect(() => {
        if (!localStorage.getItem("extensionPrompted")) {
            setTimeout(() => {
                if (window.confirm("Do you want to install our Chrome extension?")) {
                    installExtension();
                }
                localStorage.setItem("extensionPrompted", "true");
            }, 2000);
        }
    }, []);

    return (
        <div>
            <h1>Welcome to CipherWallet!</h1>
            <br></br>
            <button onClick={installExtension}>Install Extension</button>
        </div>
    );
};

export default App;
