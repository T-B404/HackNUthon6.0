chrome.runtime.onInstalled.addListener(() => {
    console.log("Blockchain Wallet Extension Installed!");
});

// Listen for messages from popup.js
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "saveWallet") {
        chrome.storage.local.set({ wallet: request.wallet }, () => {
            sendResponse({ status: "Wallet saved!" });
        });
        return true; // Keeps the response channel open
    }

    if (request.action === "getWallet") {
        chrome.storage.local.get("wallet", (data) => {
            sendResponse({ wallet: data.wallet || null });
        });
        return true;
    }

    if (request.action === "clearWallet") {
        chrome.storage.local.remove("wallet", () => {
            sendResponse({ status: "Wallet cleared!" });
        });
        return true;
    }
});